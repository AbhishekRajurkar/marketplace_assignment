package com.marketplace.wordsearch.simplewordsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleWordSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleWordSearchApplication.class, args);
	}

}
